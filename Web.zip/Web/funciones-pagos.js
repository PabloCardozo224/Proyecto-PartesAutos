//Pagar
const btnConfirmarPago = document.getElementById("btn-confirmar-pago");

if (btnConfirmarPago) {
  let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  const totalBase = carrito.reduce((acc, item) => acc + item.precio, 0);

  function actualizarTotalesPago() {
    const metodo = document.querySelector(
      'input[name="metodoPago"]:checked',
    ).value;

    let totalConDescuento = totalBase;
    if (totalBase > 10000) {
      totalConDescuento = totalBase * 0.9;
    }

    let totalFinal = totalConDescuento;
    if (metodo === "Efectivo") {
      totalFinal = totalConDescuento * 0.95;
    }

    document.getElementById("consola-totales").innerHTML = `
            <p>Precio Base: $${totalBase}</p>
            ${totalBase > 10000 ? `<p>Descuento mayorista (10%): -$${(totalBase * 0.1).toFixed(0)}</p>` : ""}
            ${metodo === "Efectivo" ? `<p>Descuento Efectivo (5%): -$${(totalConDescuento * 0.05).toFixed(0)}</p>` : ""}
            <hr>
            <p class="text-danger fw-bold fs-4">Total a Pagar: $${totalFinal.toFixed(0)}</p>
        `;

    return totalFinal.toFixed(0);
  }

  document.querySelectorAll('input[name="metodoPago"]').forEach((radio) => {
    radio.addEventListener("change", actualizarTotalesPago);
  });

  const panel = document.getElementById("consola-visual");
  if (panel) panel.style.display = "flex";

  actualizarTotalesPago();

  btnConfirmarPago.addEventListener("click", function () {
    const mensaje = document.getElementById("mensaje-pago");
    mensaje.innerHTML = "";

    const sesionString = localStorage.getItem("sesion");

    if (!sesionString) {
      mensaje.className = "alert alert-warning mt-3 text-center";
      mensaje.innerHTML = `
                <h5>No has iniciado sesión</h5>
                <p>Debes iniciar sesión o registrarte para poder confirmar tu compra.</p>
                <a href="iniciar-sesion.html" class="btn btn-danger btn-sm mt-1">Iniciar Sesión</a>
                <a href="Usuario.html" class="btn btn-outline-danger btn-sm mt-1 ms-2">Registrarse</a>
            `;
      return;
    }

    const sesion = JSON.parse(sesionString);

    if (sesion.tipo !== "cliente") {
      mensaje.className = "alert alert-info mt-3 text-center";
      mensaje.innerHTML = `<p>Has iniciado como Empleado. Para comprar, cierra sesión e ingresa como Cliente.</p>`;
      return;
    }

    if (carrito.length === 0) {
      mensaje.className = "alert alert-warning mt-3";
      mensaje.textContent = "El carrito está vacío.";
      return;
    }

    const metodo = document.querySelector(
      'input[name="metodoPago"]:checked',
    ).value;
    const montoFinal = actualizarTotalesPago();

    this.disabled = true;
    this.textContent = "Procesando...";

    const datos = {
      metodo: metodo,
      monto: montoFinal,
    };

    fetch("/api/pagos/procesar", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((data) => {
          if (!res.ok) throw new Error(data.error);
          return data;
        }),
      )
      .then((data) => {
        mensaje.className = "alert alert-success mt-3 text-center";
        mensaje.innerHTML = `<h4>¡Pago Exitoso!</h4><p>${data.mensaje}</p><p>Serás redirigido a tu ticket...</p>`;

        const ticketData = {
          productos: carrito,
          metodo: metodo,
          total: montoFinal,
          fecha: new Date().toLocaleString(),
        };
        localStorage.setItem("ultimoTicket", JSON.stringify(ticketData));

        localStorage.removeItem("carrito");

        setTimeout(() => (window.location.href = "ticket.html"), 2000);
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
        this.disabled = false;
        this.textContent = "Confirmar Pago";
      });
  });
}

//Ticket
const ticketContenedor = document.getElementById("ticket-contenido");

if (ticketContenedor) {
  const ticketString = localStorage.getItem("ultimoTicket");

  if (!ticketString) {
    ticketContenedor.innerHTML = `
            <div class="alert alert-warning text-center">
                <h4>No se encontró ningún ticket reciente</h4>
                <p>Parece que no has realizado ninguna compra.</p>
                <a href="categorias.html" class="btn btn-danger mt-2">Ir a la tienda</a>
            </div>
        `;
  } else {
    const ticket = JSON.parse(ticketString);

    let htmlProductos = "";
    ticket.productos.forEach((prod) => {
      htmlProductos += `
                <div class="d-flex justify-content-between border-bottom py-2">
                    <span>${prod.nombre} (${prod.opcion})</span>
                    <span>$${prod.precio}</span>
                </div>
            `;
    });

    ticketContenedor.innerHTML = `
            <div class="mb-4">
                <p><b>Fecha de compra:</b> ${ticket.fecha}</p>
                <p><b>Método de pago:</b> <span class="badge bg-danger">${ticket.metodo}</span></p>
            </div>
            
            <h5 class="mb-3">Productos:</h5>
            <div class="mb-4">
                ${htmlProductos}
            </div>
            
            <div class="d-flex justify-content-between align-items-center mt-3 border-top pt-3">
                <h4 class="mb-0">Total Pagado:</h4>
                <h3 class="text-danger fw-bold mb-0">$${ticket.total}</h3>
            </div>
        `;
  }
}

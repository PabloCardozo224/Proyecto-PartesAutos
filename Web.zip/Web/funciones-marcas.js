// =====================================================
// LISTADO DE MARCAS  (admin-marcas.html)
// =====================================================
const tablaMarcas = document.getElementById("tabla-marcas");

if (tablaMarcas) {
  // Variables donde guardamos lo que devuelve cada fetch.
  let listaMarcas = [];

  fetch("/api/marcas")
    .then(function (respuesta) {
      if (!respuesta.ok) throw new Error("Error HTTP: " + respuesta.status);
      return respuesta.json();
    })
    .then(function (marcas) {
      listaMarcas = marcas;

      // Segundo fetch: los productos, para contar cuantos tiene cada marca.
      return fetch("/api/productos");
    })
    .then(function (respuesta) {
      if (!respuesta.ok) throw new Error("Error HTTP: " + respuesta.status);
      return respuesta.json();
    })
    .then(function (productos) {
      tablaMarcas.innerHTML = "";

      // conteo["3"] = cantidad de productos de la marca con id 3
      const conteo = {};

      productos.forEach(function (producto) {
        if (producto.idMarca === null) return;

        if (conteo[producto.idMarca]) {
          conteo[producto.idMarca]++;
        } else {
          conteo[producto.idMarca] = 1;
        }
      });

      let sinProductos = 0;

      listaMarcas.forEach(function (marca) {
        if (!conteo[marca.id]) sinProductos++;
      });

      document.getElementById("card-marcas").textContent = listaMarcas.length;
      document.getElementById("card-productos").textContent = productos.length;
      document.getElementById("card-sin-productos").textContent = sinProductos;

      if (listaMarcas.length === 0) {
        tablaMarcas.innerHTML = `<tr><td colspan="3" class="text-center py-4">No hay marcas registradas.</td></tr>`;
        return;
      }

      listaMarcas.forEach(function (marca) {
        const fila = document.createElement("tr");

        // Nombre de la marca
        const celdaNombre = document.createElement("td");
        celdaNombre.textContent = marca.nombre;
        celdaNombre.style.fontWeight = "bold";
        fila.appendChild(celdaNombre);

        // Cantidad de productos
        const celdaCantidad = document.createElement("td");
        celdaCantidad.textContent = (conteo[marca.id] || 0) + " productos";
        fila.appendChild(celdaCantidad);

        // Botones
        const celdaAcciones = document.createElement("td");

        const botonEditar = document.createElement("a");
        botonEditar.href = "/editar-marca.html?id=" + marca.id;
        botonEditar.className = "btn btn-warning btn-sm me-2";
        botonEditar.textContent = "Editar";
        celdaAcciones.appendChild(botonEditar);

        const botonEliminar = document.createElement("button");
        botonEliminar.type = "button";
        botonEliminar.className = "btn btn-danger btn-sm";
        botonEliminar.textContent = "Eliminar";

        botonEliminar.addEventListener("click", function () {
          if (
            confirm(
              "¿Seguro que querés eliminar la marca " + marca.nombre + "?",
            )
          ) {
            fetch("/api/marcas/eliminar", {
              method: "POST",
              headers: {
                "Content-Type": "application/x-www-form-urlencoded",
              },
              body: new URLSearchParams({
                id: marca.id,
              }).toString(),
            })
              .then(function (respuesta) {
                return respuesta.json().then(function (datos) {
                  if (!respuesta.ok) {
                    throw new Error(datos.error || "No se pudo eliminar.");
                  }
                  return datos;
                });
              })
              .then(function () {
                window.location.reload();
              })
              .catch(function (error) {
                alert(error.message);
              });
          }
        });

        celdaAcciones.appendChild(botonEliminar);
        fila.appendChild(celdaAcciones);
        tablaMarcas.appendChild(fila);
      });
    })
    .catch(function (error) {
      console.error("Error al cargar las marcas:", error);
      tablaMarcas.innerHTML = `<tr><td colspan="3" class="text-center text-danger py-4">No se pudieron cargar las marcas.</td></tr>`;
    });
}

// =====================================================
// NUEVA MARCA  (nueva-marca.html)
// =====================================================
const formularioMarca = document.getElementById("formulario-marca");

if (formularioMarca) {
  const mensajeNueva = document.getElementById("mensaje");

  formularioMarca.addEventListener("submit", function (evento) {
    evento.preventDefault();

    fetch("/api/marcas/crear", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        nombre: document.getElementById("nombre").value,
      }).toString(),
    })
      .then(function (respuesta) {
        return respuesta.json().then(function (datos) {
          if (!respuesta.ok) {
            throw new Error(datos.error || "No se pudo guardar la marca.");
          }
          return datos;
        });
      })
      .then(function (datos) {
        mensajeNueva.className = "alert alert-success mt-3";
        mensajeNueva.textContent = datos.mensaje;

        formularioMarca.reset();
      })
      .catch(function (error) {
        mensajeNueva.className = "alert alert-danger mt-3";
        mensajeNueva.textContent = error.message;
      });
  });
}

// =====================================================
// EDITAR MARCA  (editar-marca.html)
// =====================================================
const formularioEditarMarca = document.getElementById(
  "formulario-editar-marca",
);

if (formularioEditarMarca) {
  const mensajeEditar = document.getElementById("mensaje");

  // El id viene en la direccion: editar-marca.html?id=3
  const parametros = new URLSearchParams(window.location.search);
  const idMarcaEditar = parametros.get("id");

  if (!idMarcaEditar || !/^[0-9]+$/.test(idMarcaEditar)) {
    mensajeEditar.className = "alert alert-danger";
    mensajeEditar.textContent = "El ID de la marca no es válido.";
    formularioEditarMarca.style.display = "none";
  } else {
    // Buscamos la marca en la lista y rellenamos el formulario.
    fetch("/api/marcas")
      .then(function (respuesta) {
        if (!respuesta.ok) throw new Error("No se pudo consultar la marca.");
        return respuesta.json();
      })
      .then(function (marcas) {
        const marca = marcas.find(function (elemento) {
          return String(elemento.id) === idMarcaEditar;
        });

        if (!marca) throw new Error("No se encontró la marca.");

        document.getElementById("id").value = marca.id;
        document.getElementById("nombre").value = marca.nombre;
      })
      .catch(function (error) {
        mensajeEditar.className = "alert alert-danger";
        mensajeEditar.textContent = error.message;
        formularioEditarMarca.style.display = "none";
      });
  }

  formularioEditarMarca.addEventListener("submit", function (evento) {
    evento.preventDefault();

    fetch("/api/marcas/editar", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        id: document.getElementById("id").value,
        nombre: document.getElementById("nombre").value,
      }).toString(),
    })
      .then(function (respuesta) {
        return respuesta.json().then(function (datos) {
          if (!respuesta.ok) {
            throw new Error(datos.error || "No se pudo editar.");
          }
          return datos;
        });
      })
      .then(function (datos) {
        mensajeEditar.className = "alert alert-success";
        mensajeEditar.textContent = datos.mensaje;

        setTimeout(function () {
          window.location.href = "/admin-marcas.html";
        }, 1000);
      })
      .catch(function (error) {
        mensajeEditar.className = "alert alert-danger";
        mensajeEditar.textContent = error.message;
      });
  });
}

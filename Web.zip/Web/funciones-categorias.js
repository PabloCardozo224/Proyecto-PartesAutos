const tabla = document.getElementById("tabla-categorias");

if (tabla) {
  fetch("/api/productos")
    .then(function (respuesta) {
      if (!respuesta.ok) throw new Error("Error HTTP: " + respuesta.status);
      return respuesta.json();
    })
    .then(function (productos) {
      tabla.innerHTML = "";

      const conteo = {};

      productos.forEach(function (producto) {
        const cat = producto.tipoParte;
        if (!cat) return;

        if (conteo[cat]) {
          conteo[cat]++;
        } else {
          conteo[cat] = 1;
        }
      });

      const categorias = Object.keys(conteo);

      document.getElementById("card-productos").textContent = productos.length;
      document.getElementById("card-categorias").textContent =
        categorias.length;

      if (categorias.length === 0) {
        tabla.innerHTML = `<tr><td colspan="3" class="text-center py-4">No hay categorías registradas.</td></tr>`;
        return;
      }

      categorias.forEach(function (nombreCat) {
        const fila = document.createElement("tr");

        const celdaNombre = document.createElement("td");
        celdaNombre.textContent = nombreCat;
        celdaNombre.style.fontWeight = "bold";
        fila.appendChild(celdaNombre);

        const celdaCantidad = document.createElement("td");
        celdaCantidad.textContent = conteo[nombreCat] + " productos";
        fila.appendChild(celdaCantidad);

        const celdaAccion = document.createElement("td");
        const boton = document.createElement("a");
        boton.href = "/admin-productos.html";
        boton.className = "btn btn-primary btn-sm";
        boton.textContent = "Ver productos";
        celdaAccion.appendChild(boton);

        fila.appendChild(celdaAccion);

        tabla.appendChild(fila);
      });
    })
    .catch(function (error) {
      console.error("Error al cargar las categorías:", error);
      tabla.innerHTML = `<tr><td colspan="3" class="text-center text-danger py-4">No se pudieron cargar las categorías.</td></tr>`;
    });
}

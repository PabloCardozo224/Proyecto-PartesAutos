//Registro de usuarios
const formRegistro = document.getElementById("formulario-registro");
if (formRegistro) {
  const mensaje = document.getElementById("mensaje");

  const btnRegistrarse = document.getElementById("btn-registrarse");
  if (btnRegistrarse) {
    btnRegistrarse.addEventListener("click", function () {
      formRegistro.requestSubmit();
    });
  }

  formRegistro.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const datos = {
      nombre: document.getElementById("nombre").value,
      apellido: document.getElementById("apellido").value,
      usuario: document.getElementById("usuario").value,
      contrasena: document.getElementById("contrasena").value,
      correo: document.getElementById("correo").value,
      dni: document.getElementById("dni").value,
      telefono: document.getElementById("telefono").value,
      direccion: document.getElementById("direccion").value,
    };
    fetch("/api/registro", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((data) => {
          if (!res.ok) throw new Error(data.error);
          return data;
        }),
      )
      .then((data) => {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = data.mensaje;
        formRegistro.reset();
        setTimeout(() => (window.location.href = "/iniciar-sesion.html"), 2000);
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
      });
  });
}

//Inicio de sesión
const formLogin = document.getElementById("formulario-login");
if (formLogin) {
  const mensaje = document.getElementById("mensaje");

  const btnLogin = document.getElementById("btn-login");
  if (btnLogin) {
    btnLogin.addEventListener("click", function () {
      formLogin.requestSubmit();
    });
  }

  formLogin.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const datos = {
      usuario: document.getElementById("usuario").value,
      contrasena: document.getElementById("contrasena").value,
    };
    fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((sesion) => {
          if (!res.ok) throw new Error(sesion.error);
          return sesion;
        }),
      )
      .then((sesion) => {
        localStorage.setItem("sesion", JSON.stringify(sesion));
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = "Bienvenido/a " + sesion.nombre;
        setTimeout(() => {
          if (sesion.tipo === "empleado" && sesion.puesto === "Gerente") {
            window.location.href = "/admin-productos.html";
          } else {
            window.location.href = "/PaginaInicio.html";
          }
        }, 1500);
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
      });
  });
}

//Tabla de usuarios
const tablaUsuarios = document.getElementById("tabla-usuarios");
if (tablaUsuarios) {
  fetch("/api/clientes")
    .then((res) => res.json())
    .then((clientes) => {
      tablaUsuarios.innerHTML = "";
      document.getElementById("card-usuarios").textContent = clientes.length;

      if (clientes.length === 0) {
        tablaUsuarios.innerHTML = `<tr><td colspan="8" class="text-center py-4">No hay usuarios registrados.</td></tr>`;
        return;
      }

      clientes.forEach((cliente) => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td><b>${cliente.nombre}</b></td>
            <td>${cliente.apellido}</td>
            <td>${cliente.usuario}</td>
            <td>${cliente.dni}</td>
            <td>${cliente.telefono}</td>
            <td>${cliente.direccion}</td>
            <td>${cliente.correo || '<span class="text-muted">Sin correo</span>'}</td>
            <td>
              <a href="/editar-usuario.html?id=${cliente.id}" class="btn btn-warning btn-sm me-2">Editar</a>
              <button class="btn btn-danger btn-sm btn-eliminar" data-id="${cliente.id}">Eliminar</button>
            </td>
          `;
        fila
          .querySelector(".btn-eliminar")
          .addEventListener("click", function () {
            if (
              confirm("¿Seguro que querés eliminar a " + cliente.nombre + "?")
            ) {
              fetch("/api/clientes/eliminar", {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams({ id: cliente.id }).toString(),
              })
                .then((res) =>
                  res.json().then((d) => {
                    if (!res.ok) throw new Error(d.error);
                    return d;
                  }),
                )
                .then(() => window.location.reload())
                .catch((err) => alert(err.message));
            }
          });
        tablaUsuarios.appendChild(fila);
      });
    })
    .catch((err) => {
      console.error(err);
      tablaUsuarios.innerHTML = `<tr><td colspan="8" class="text-center text-danger py-4">Error al cargar usuarios.</td></tr>`;
    });
}

const formCrearUsuario = document.getElementById("formulario-crear-usuario");
if (formCrearUsuario) {
  const mensaje = document.getElementById("mensaje");
  formCrearUsuario.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const datos = {
      nombre: document.getElementById("nombre").value,
      apellido: document.getElementById("apellido").value,
      usuario: document.getElementById("usuario").value,
      contrasena: document.getElementById("contrasena").value,
      dni: document.getElementById("dni").value,
      telefono: document.getElementById("telefono").value,
      direccion: document.getElementById("direccion").value,
      correo: document.getElementById("correo").value,
    };
    fetch("/api/clientes/crear", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((data) => {
          if (!res.ok) throw new Error(data.error);
          return data;
        }),
      )
      .then((data) => {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = data.mensaje;
        formCrearUsuario.reset();
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
      });
  });
}

const formEditarUsuario = document.getElementById("formulario-editar-usuario");
if (formEditarUsuario) {
  const mensaje = document.getElementById("mensaje");
  const parametros = new URLSearchParams(window.location.search);
  const idUsuario = parametros.get("id");

  if (idUsuario) {
    fetch("/api/clientes")
      .then((res) => res.json())
      .then((clientes) => {
        const cliente = clientes.find((c) => String(c.id) === idUsuario);
        if (cliente) {
          document.getElementById("id").value = cliente.id;
          document.getElementById("nombre").value = cliente.nombre;
          document.getElementById("apellido").value = cliente.apellido;
          document.getElementById("usuario").value = cliente.usuario;
          document.getElementById("dni").value = cliente.dni;
          document.getElementById("telefono").value = cliente.telefono;
          document.getElementById("direccion").value = cliente.direccion;
          document.getElementById("correo").value = cliente.correo || "";
        } else {
          mensaje.className = "alert alert-danger";
          mensaje.textContent = "No se encontró el usuario.";
        }
      });
  }

  formEditarUsuario.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const datos = {
      id: document.getElementById("id").value,
      nombre: document.getElementById("nombre").value,
      apellido: document.getElementById("apellido").value,
      usuario: document.getElementById("usuario").value,
      dni: document.getElementById("dni").value,
      telefono: document.getElementById("telefono").value,
      direccion: document.getElementById("direccion").value,
      correo: document.getElementById("correo").value,
    };
    fetch("/api/clientes/editar", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((data) => {
          if (!res.ok) throw new Error(data.error);
          return data;
        }),
      )
      .then((data) => {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = data.mensaje;
        setTimeout(() => (window.location.href = "/admin-usuario.html"), 1500);
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
      });
  });
}

// Carrito

function activarCarrito() {
  const panel = document.getElementById("consola-visual");
  if (panel) {
    panel.classList.toggle("carrito-abierto");
    recalcularTotal();
    renderCarrito();
  }
}

function cerrarCarrito() {
  const panel = document.getElementById("consola-visual");
  if (panel) {
    panel.classList.remove("carrito-abierto");
  }
}

let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
let totalCompra = 0;
let proximoIdCarrito =
  carrito.length > 0 ? Math.max(...carrito.map((item) => item.id)) + 1 : 1;

function guardarEnLocalStorage() {
  localStorage.setItem("carrito", JSON.stringify(carrito));
}

function recalcularTotal() {
  totalCompra = carrito.reduce(function (acc, item) {
    return acc + item.precio;
  }, 0);
}

function actualizarTotales() {
  let totalConDescuento = totalCompra;

  if (totalCompra > 10000) {
    totalConDescuento = totalCompra * 0.9;
  }

  const totalEfectivo = totalConDescuento * 0.95;

  document.getElementById("consola-totales").innerHTML = `
        <p>Precio Total: $${totalCompra.toFixed(0)}</p>
        ${totalCompra > 10000 ? `<p>Precio Total mayor a $10000 (10% off): $${totalConDescuento.toFixed(0)}</p>` : ""}
        <p>Precio Total en efectivo (5% off): $${totalEfectivo.toFixed(0)}</p>
    `;
}

function renderCarrito() {
  const contenedor = document.getElementById("consola-mensajes");
  if (!contenedor) return;

  contenedor.innerHTML = "";

  if (carrito.length === 0) {
    const p = document.createElement("p");
    p.textContent = "El carrito esta vacio.";
    contenedor.appendChild(p);
    return;
  }

  carrito.forEach(function (item) {
    const linea = document.createElement("p");

    const texto = document.createElement("span");
    texto.textContent = `${item.nombre} (${item.opcion}) - $${item.precio}`;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn_eliminar_item";
    btn.textContent = "×";
    btn.title = "Eliminar del carrito";
    btn.addEventListener("click", function () {
      eliminarDelCarrito(item.id);
    });

    linea.appendChild(texto);
    linea.appendChild(btn);
    contenedor.appendChild(linea);
  });
}

function agregarProducto(nombreProducto, precioBase, idCheckbox) {
  let opcion = "Estandar";

  const checkbox = idCheckbox ? document.getElementById(idCheckbox) : null;
  const quiereGarantia = checkbox ? checkbox.checked : false;

  if (quiereGarantia) {
    precioBase += 10000;
    opcion = "Con garantia extendida";
  }

  carrito.push({
    id: proximoIdCarrito++,
    nombre: nombreProducto,
    precio: precioBase,
    opcion: opcion,
  });

  guardarEnLocalStorage();

  recalcularTotal();
  actualizarTotales();
  renderCarrito();
}

function eliminarDelCarrito(id) {
  carrito = carrito.filter(function (item) {
    return item.id !== id;
  });

  guardarEnLocalStorage();

  recalcularTotal();
  actualizarTotales();
  renderCarrito();
}

recalcularTotal();
actualizarTotales();
renderCarrito();

// Favoritos

function activarFavoritos() {
  const panel = document.getElementById("panel-favoritos");
  if (panel) {
    panel.classList.toggle("favoritos-open");
    renderFavoritos();
  }
}

function cerrarFavoritos() {
  const panel = document.getElementById("panel-favoritos");
  if (panel) {
    panel.classList.remove("favoritos-open");
  }
}

let favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];
let proximoIdFavorito =
  favoritos.length > 0 ? Math.max(...favoritos.map((item) => item.id)) + 1 : 1;

function guardarFavoritosEnLocalStorage() {
  localStorage.setItem("favoritos", JSON.stringify(favoritos));
}

function pintarCorazon(idBoton, activo) {
  const boton = document.getElementById(idBoton);
  if (!boton) return;

  boton.classList.toggle("activo", activo);
  const icono = boton.querySelector("i");
  if (icono) {
    icono.classList.toggle("fa-solid", activo);
    icono.classList.toggle("fa-regular", !activo);
  }
}

function renderFavoritos() {
  const contenedor = document.getElementById("lista-favoritos");
  if (!contenedor) return;

  contenedor.innerHTML = "";

  if (favoritos.length === 0) {
    const p = document.createElement("p");
    p.textContent = "No tienes favoritos guardados.";
    contenedor.appendChild(p);
    return;
  }

  favoritos.forEach(function (item) {
    const linea = document.createElement("p");

    const texto = document.createElement("span");
    texto.textContent = `${item.nombre} - $${item.precio}`;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn_eliminar_item";
    btn.textContent = "×";
    btn.title = "Quitar de favoritos";
    btn.addEventListener("click", function () {
      eliminarFavorito(item.id);
    });

    linea.appendChild(texto);
    linea.appendChild(btn);
    contenedor.appendChild(linea);
  });
}

function agregarFavorito(nombre, precio, boton) {
  if (!boton) return;

  const existente = favoritos.find(function (item) {
    return item.nombre === nombre;
  });

  if (existente) {
    eliminarFavorito(existente.id);
    return;
  }

  favoritos.push({
    id: proximoIdFavorito++,
    nombre: nombre,
    precio: precio,
    idBoton: boton.id,
  });

  guardarFavoritosEnLocalStorage();
  pintarCorazon(boton.id, true);
  renderFavoritos();
}

function eliminarFavorito(id) {
  const eliminado = favoritos.find(function (item) {
    return item.id === id;
  });

  favoritos = favoritos.filter(function (item) {
    return item.id !== id;
  });

  guardarFavoritosEnLocalStorage();

  if (eliminado) {
    pintarCorazon(eliminado.idBoton, false);
  }
  renderFavoritos();
}

function sincronizarCorazones() {
  favoritos.forEach(function (item) {
    pintarCorazon(item.idBoton, true);
  });
}

renderFavoritos();
sincronizarCorazones();

// Lista de productos
const productosBusqueda = [
  { nombre: "Filtro de Aceite", categoria: "Filtros", precio: 5000 },
  { nombre: "Pastillas de Freno", categoria: "Frenos", precio: 5000 },
  { nombre: "Amortiguador", categoria: "Suspension", precio: 5000 },
  { nombre: "Faro Delantero", categoria: "Iluminacion", precio: 5000 },
  { nombre: "Bomba de Agua", categoria: "Motor", precio: 5000 },
  { nombre: "Kit de Embrague", categoria: "Embrague", precio: 5000 },
  { nombre: "Bateria", categoria: "Electrico", precio: 5000 },
];

//Buscador
const inputBuscador = document.getElementById("buscador");
const equisInput = document.getElementById("equis");
const contenedorResultados = document.getElementById("contenedor-resultados");

inputBuscador.addEventListener("input", () => {
  const texto = inputBuscador.value.toLowerCase().trim();

  if (texto.length > 0) {
    equisInput.style.display = "block";
  } else {
    equisInput.style.display = "none";
    contenedorResultados.style.display = "none";
    return;
  }

  const resultados = productosBusqueda.filter((producto) =>
    producto.nombre.toLowerCase().includes(texto),
  );

  mostrarResultados(resultados, texto);
});

function mostrarResultados(lista, textoBuscado) {
  contenedorResultados.innerHTML = "";

  if (lista.length === 0) {
    contenedorResultados.innerHTML = `<span class="no-resultados">No se encontraron resultados para "${textoBuscado}"</span>`;
  } else {
    lista.forEach((producto) => {
      const divResultado = document.createElement("div");
      divResultado.classList.add("resultado");

      divResultado.innerHTML = `
                <h4>${producto.nombre}</h4>
                <a href="categorias.html#${producto.categoria}">
                    <ion-icon name="settings-outline"></ion-icon>
                    <span>${producto.categoria} - $${producto.precio}</span>
                </a>
            `;
      contenedorResultados.appendChild(divResultado);
    });
  }

  contenedorResultados.style.display = "flex";
}

equisInput.addEventListener("click", () => {
  inputBuscador.value = "";
  equisInput.style.display = "none";
  contenedorResultados.style.display = "none";
  contenedorResultados.innerHTML = "";
});

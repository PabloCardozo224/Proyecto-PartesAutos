const contenedor = document.getElementById("contenedor-perfil");
const nombrePerfil = document.getElementById("cabecera-perfil");

const sesionString = localStorage.getItem("sesion");

if (!sesionString) {
  contenedor.innerHTML = `
        <div class="alert alert-warning text-center m-0">
            <h4>No has iniciado sesión o No estás registrado</h4>
            <p>Para ver tu perfil o editar tus datos, por favor <a href="iniciar-sesion.html" class="btn btn-danger">inicia sesión</a></p>
            <p class="mt-3">Si no tienes una cuenta, puedes <a href="Usuario.html" class="btn btn-danger">registrarte</a></p>
        </div>
    `;
} else {
  const sesion = JSON.parse(sesionString);

  if (sesion.tipo === "empleado") {
    contenedor.innerHTML = `
            <div class="alert alert-info text-center m-0">
                <h4>Hola, ${sesion.nombre}</h4>
                <p>Has iniciado sesión como <b>Empleado (${sesion.puesto})</b>.</p>
                <p>Los empleados no editan su perfil desde acá. Por favor, accedé al panel de administración.</p>
                <a href="admin-empleados.html" class="btn btn-dark mb-3">Ir al Panel de Admin</a>
                <p>Si deseas cerrar tu sesión, haz clic en el botón de abajo:</p>
                <button type="button" id="btn-cerrar-sesion" class="btn btn-secondary w-50">Cerrar Sesión</button>
            </div>
            <div id="mensaje" class="mt-3"></div>
        `;
    configurarCerrarSesion();
  } else if (sesion.tipo === "cliente") {
    mostrarFormularioCliente(sesion);
  }
}

function mostrarFormularioCliente(sesion) {
  fetch("/api/clientes")
    .then((res) => res.json())
    .then((clientes) => {
      const cliente = clientes.find((c) => String(c.id) === String(sesion.id));

      if (!cliente) {
        contenedor.innerHTML = `<div class="alert alert-danger">Error: No se encontraron los datos.</div>`;
        return;
      }

      nombrePerfil.innerHTML = `<h3>Mi Perfil: ${cliente.nombre} ${cliente.apellido}</h3>`;

      contenedor.innerHTML = `
                <form id="formulario-perfil">
                    <input type="hidden" id="id" value="${cliente.id}">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nombre</label>
                            <input type="text" id="nombre" class="form-control" value="${cliente.nombre}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Apellido</label>
                            <input type="text" id="apellido" class="form-control" value="${cliente.apellido}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Usuario</label>
                            <input type="text" id="usuario" class="form-control" value="${cliente.usuario}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nueva Contraseña</label>
                            <input type="password" id="contrasena" class="form-control" placeholder="Dejar en blanco para no cambiar">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">DNI</label>
                            <input type="number" id="dni" class="form-control" value="${cliente.dni}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Teléfono</label>
                            <input type="text" id="telefono" class="form-control" value="${cliente.telefono}" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Dirección</label>
                            <input type="text" id="direccion" class="form-control" value="${cliente.direccion}" required>
                        </div>
                        <div class="col-md-12 mb-4">
                            <label class="form-label">Correo</label>
                            <input type="email" id="correo" class="form-control" value="${cliente.correo || ""}">
                        </div>
                    </div>
                    <div class="d-flex gap-2 mt-3">
                        <button type="submit" class="btn btn-danger w-50">Guardar Cambios</button>
                        <button type="button" id="btn-cerrar-sesion" class="btn btn-secondary w-50">Cerrar Sesión</button>
                    </div>
                    <div id="mensaje" class="mt-3"></div>
                </form>
            `;

      document
        .getElementById("formulario-perfil")
        .addEventListener("submit", function (e) {
          e.preventDefault();
          guardarPerfil();
        });

      configurarCerrarSesion();
    });
}

function configurarCerrarSesion() {
  const btnCerrar = document.getElementById("btn-cerrar-sesion");
  if (btnCerrar) {
    btnCerrar.addEventListener("click", function () {
      if (confirm("¿Seguro que querés cerrar sesión?")) {
        localStorage.removeItem("sesion");
        localStorage.removeItem("carrito"); // Limpiamos el carrito por seguridad
        window.location.href = "PaginaInicio.html";
      }
    });
  }
}

function guardarPerfil() {
  const mensaje = document.getElementById("mensaje");
  const nuevaContrasena = document.getElementById("contrasena").value;

  const datos = {
    id: document.getElementById("id").value,
    nombre: document.getElementById("nombre").value,
    apellido: document.getElementById("apellido").value,
    usuario: document.getElementById("usuario").value,
    dni: document.getElementById("dni").value,
    telefono: document.getElementById("telefono").value,
    direccion: document.getElementById("direccion").value,
    correo: document.getElementById("correo").value,
  };

  if (nuevaContrasena.trim() !== "") {
    datos.contrasena = nuevaContrasena;
  }

  fetch("/api/clientes/editar", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(datos).toString(),
  })
    .then((res) =>
      res.json().then((data) => {
        if (!res.ok) throw new Error(data.error);
        return data;
      }),
    )
    .then((data) => {
      mensaje.className = "alert alert-success";
      mensaje.textContent = "Datos actualizados correctamente.";

      const sesion = JSON.parse(localStorage.getItem("sesion"));
      sesion.nombre = datos.nombre;
      sesion.apellido = datos.apellido;
      localStorage.setItem("sesion", JSON.stringify(sesion));
    })
    .catch((err) => {
      mensaje.className = "alert alert-danger";
      mensaje.textContent = err.message;
    });
}

const tablaEnvios = document.getElementById("tabla-envios");

if (tablaEnvios) {
  fetch("/api/envios")
    .then(function (respuesta) {
      if (!respuesta.ok) throw new Error("Error al cargar envíos");
      return respuesta.json();
    })
    .then(function (envios) {
      tablaEnvios.innerHTML = "";
      document.getElementById("card-envios").textContent = envios.length;

      if (envios.length === 0) {
        tablaEnvios.innerHTML = `<tr><td colspan="6" class="text-center py-4">No hay envíos registrados.</td></tr>`;
        return;
      }

      envios.forEach(function (envio) {
        const fila = document.createElement("tr");

        fila.innerHTML = `
            <td><b>${envio.nCasa}</b></td>
            <td>${envio.calle}</td>
            <td>${envio.barrio}</td>
            <td>${envio.provincia}</td>
            <td>${envio.localidad}</td>
            <td>
              <a href="/editar-envio.html?id=${envio.id}" class="btn btn-warning btn-sm me-2">Editar</a>
              <button class="btn btn-danger btn-sm btn-eliminar" data-id="${envio.id}">Eliminar</button>
            </td>
          `;

        const botonEliminar = fila.querySelector(".btn-eliminar");
        botonEliminar.addEventListener("click", function () {
          if (confirm("¿Seguro que querés eliminar este envío?")) {
            fetch("/api/envios/eliminar", {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: new URLSearchParams({ id: envio.id }).toString(),
            })
              .then(function (respuesta) {
                return respuesta.json().then(function (datos) {
                  if (!respuesta.ok)
                    throw new Error(datos.error || "No se pudo eliminar.");
                  return datos;
                });
              })
              .then(function () {
                window.location.reload();
              })
              .catch(function (error) {
                alert(error.message);
              });
          }
        });

        tablaEnvios.appendChild(fila);
      });
    })
    .catch(function (error) {
      console.error(error);
      tablaEnvios.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Error al cargar envíos.</td></tr>`;
    });
}

const formCrearEnvio = document.getElementById("formulario-envio");

if (formCrearEnvio) {
  const mensaje = document.getElementById("mensaje");

  formCrearEnvio.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const datos = {
      nCasa: document.getElementById("nCasa").value,
      calle: document.getElementById("calle").value,
      barrio: document.getElementById("barrio").value,
      provincia: document.getElementById("provincia").value,
      localidad: document.getElementById("localidad").value,
    };

    fetch("/api/envios/crear", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then(function (respuesta) {
        return respuesta.json().then(function (datos) {
          if (!respuesta.ok)
            throw new Error(datos.error || "No se pudo guardar.");
          return datos;
        });
      })
      .then(function (datos) {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = datos.mensaje;
        formCrearEnvio.reset();
      })
      .catch(function (error) {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = error.message;
      });
  });
}

const formEditarEnvio = document.getElementById("formulario-editar-envio");

if (formEditarEnvio) {
  const mensaje = document.getElementById("mensaje");
  const parametros = new URLSearchParams(window.location.search);
  const idEnvio = parametros.get("id");

  // 1. Cargar los datos en el formulario
  if (idEnvio) {
    fetch("/api/envios")
      .then((res) => res.json())
      .then(function (envios) {
        const envio = envios.find(function (e) {
          return String(e.id) === idEnvio;
        });
        if (envio) {
          document.getElementById("id").value = envio.id;
          document.getElementById("nCasa").value = envio.nCasa;
          document.getElementById("calle").value = envio.calle;
          document.getElementById("barrio").value = envio.barrio;
          document.getElementById("provincia").value = envio.provincia;
          document.getElementById("localidad").value = envio.localidad;
        } else {
          mensaje.className = "alert alert-danger";
          mensaje.textContent = "No se encontró el envío.";
        }
      });
  }

  formEditarEnvio.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const datos = {
      id: document.getElementById("id").value,
      nCasa: document.getElementById("nCasa").value,
      calle: document.getElementById("calle").value,
      barrio: document.getElementById("barrio").value,
      provincia: document.getElementById("provincia").value,
      localidad: document.getElementById("localidad").value,
    };

    fetch("/api/envios/editar", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then(function (respuesta) {
        return respuesta.json().then(function (datos) {
          if (!respuesta.ok)
            throw new Error(datos.error || "No se pudo editar.");
          return datos;
        });
      })
      .then(function (datos) {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = datos.mensaje;
        setTimeout(function () {
          window.location.href = "/admin-pedidos.html";
        }, 1000);
      })
      .catch(function (error) {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = error.message;
      });
  });
}

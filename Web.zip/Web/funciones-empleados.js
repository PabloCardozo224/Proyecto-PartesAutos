// Tabla
const tablaEmpleados = document.getElementById("tabla-empleados");
if (tablaEmpleados) {
  fetch("/api/empleados")
    .then((res) => res.json())
    .then((empleados) => {
      tablaEmpleados.innerHTML = "";
      document.getElementById("card-empleados").textContent = empleados.length;

      if (empleados.length === 0) {
        tablaEmpleados.innerHTML = `<tr><td colspan="8" class="text-center py-4">No hay empleados registrados.</td></tr>`;
        return;
      }

      empleados.forEach((empleado) => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td><b>${empleado.nombre}</b></td>
            <td>${empleado.apellido}</td>
            <td>${empleado.usuario}</td>
            <td>${empleado.dni}</td>
            <td>${empleado.telefono}</td>
            <td>${empleado.puesto}</td>
            <td>${empleado.rol}</td>
            <td>
              <a href="/editar-empleado.html?id=${empleado.id}" class="btn btn-warning btn-sm me-2">Editar</a>
              <button class="btn btn-danger btn-sm btn-eliminar" data-id="${empleado.id}">Eliminar</button>
            </td>
          `;
        fila
          .querySelector(".btn-eliminar")
          .addEventListener("click", function () {
            if (
              confirm("¿Seguro que querés eliminar a " + empleado.nombre + "?")
            ) {
              fetch("/api/empleados/eliminar", {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                },
                body: new URLSearchParams({ id: empleado.id }).toString(),
              })
                .then((res) =>
                  res.json().then((d) => {
                    if (!res.ok) throw new Error(d.error);
                    return d;
                  }),
                )
                .then(() => window.location.reload())
                .catch((err) => alert(err.message));
            }
          });
        tablaEmpleados.appendChild(fila);
      });
    })
    .catch((err) => {
      console.error(err);
      tablaEmpleados.innerHTML = `<tr><td colspan="8" class="text-center text-danger py-4">Error al cargar empleados.</td></tr>`;
    });
}

// Crear
const formCrearEmpleado = document.getElementById("formulario-crear-empleado"); // ID corregido
if (formCrearEmpleado) {
  const mensaje = document.getElementById("mensaje");
  formCrearEmpleado.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const datos = {
      nombre: document.getElementById("nombre").value,
      apellido: document.getElementById("apellido").value,
      usuario: document.getElementById("usuario").value,
      contrasena: document.getElementById("contrasena").value,
      dni: document.getElementById("dni").value,
      telefono: document.getElementById("telefono").value,
      puesto: document.getElementById("puesto").value,
      rol: document.getElementById("rol").value,
    };
    fetch("/api/empleados/crear", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((data) => {
          if (!res.ok) throw new Error(data.error);
          return data;
        }),
      )
      .then((data) => {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = data.mensaje;
        formCrearEmpleado.reset();
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
      });
  });
}

// Editar
const formEditarEmpleado = document.getElementById(
  "formulario-editar-empleado",
); // ID corregido
if (formEditarEmpleado) {
  const mensaje = document.getElementById("mensaje");
  const parametros = new URLSearchParams(window.location.search);
  const idUsuario = parametros.get("id");

  if (idUsuario) {
    fetch("/api/empleados")
      .then((res) => res.json())
      .then((empleados) => {
        const empleado = empleados.find((e) => String(e.id) === idUsuario);
        if (empleado) {
          document.getElementById("id").value = empleado.id;
          document.getElementById("nombre").value = empleado.nombre;
          document.getElementById("apellido").value = empleado.apellido;
          document.getElementById("usuario").value = empleado.usuario;
          document.getElementById("contrasena").value = empleado.contrasena; // Trae la contraseña
          document.getElementById("dni").value = empleado.dni;
          document.getElementById("telefono").value = empleado.telefono;
          document.getElementById("puesto").value = empleado.puesto;
          document.getElementById("rol").value = empleado.rol;
        } else {
          mensaje.className = "alert alert-danger";
          mensaje.textContent = "No se encontró el empleado.";
        }
      });
  }

  formEditarEmpleado.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const datos = {
      id: document.getElementById("id").value,
      nombre: document.getElementById("nombre").value,
      apellido: document.getElementById("apellido").value,
      usuario: document.getElementById("usuario").value,
      contrasena: document.getElementById("contrasena").value, // Envia la contraseña
      dni: document.getElementById("dni").value,
      telefono: document.getElementById("telefono").value,
      puesto: document.getElementById("puesto").value,
      rol: document.getElementById("rol").value,
    };
    fetch("/api/empleados/editar", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(datos).toString(),
    })
      .then((res) =>
        res.json().then((data) => {
          if (!res.ok) throw new Error(data.error);
          return data;
        }),
      )
      .then((data) => {
        mensaje.className = "alert alert-success mt-3";
        mensaje.textContent = data.mensaje;
        setTimeout(
          () => (window.location.href = "/admin-empleados.html"),
          1500,
        ); // URL corregida
      })
      .catch((err) => {
        mensaje.className = "alert alert-danger mt-3";
        mensaje.textContent = err.message;
      });
  });
}

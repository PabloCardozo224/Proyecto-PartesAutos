//Tabla
const tabla = document.getElementById("tabla-productos");

if (tabla) {
    function cambiarTarjeta(id, valor) {
        const tarjeta = document.getElementById(id);
        if (tarjeta) tarjeta.textContent = valor;
    }

    fetch("/api/productos")
      .then(function (respuesta) {
        if (!respuesta.ok) throw new Error("Error HTTP: " + respuesta.status);
        return respuesta.json();
      })
      .then(function (productos) {
        tabla.innerHTML = "";

        const categorias = new Set();
        const marcas = new Set();
        let stockBajo = 0;

        productos.forEach(function (producto) {
          categorias.add(producto.tipoParte);
          if (producto.marca) marcas.add(producto.marca);
          if (producto.cantidad <= 20) stockBajo++;
        });

        cambiarTarjeta("card-productos", productos.length);
        cambiarTarjeta("card-categorias", categorias.size);
        cambiarTarjeta("card-stock", stockBajo);
        cambiarTarjeta("card-marcas", marcas.size);

        if (productos.length === 0) {
          tabla.innerHTML = `<tr><td colspan="6" class="text-center py-4">No hay productos registrados.</td></tr>`;
          return;
        }

        productos.forEach(function (producto) {
          const fila = document.createElement("tr");

          const celdaNombre = document.createElement("td");
          celdaNombre.textContent = producto.nombre + " - " + producto.modelo;
          fila.appendChild(celdaNombre);

          const celdaCategoria = document.createElement("td");
          celdaCategoria.textContent = producto.tipoParte;
          fila.appendChild(celdaCategoria);

          const celdaMarca = document.createElement("td");
          celdaMarca.textContent = producto.marca || "Sin marca";
          fila.appendChild(celdaMarca);

          const celdaStock = document.createElement("td");
          celdaStock.textContent = producto.cantidad;
          fila.appendChild(celdaStock);

          const celdaEstado = document.createElement("td");
          const estado = document.createElement("span");

          if (producto.cantidad === 0) {
            estado.className = "agotado";
            estado.textContent = "Agotado";
          } else if (producto.cantidad <= 20) {
            estado.className = "bajo";
            estado.textContent = "Stock bajo";
          } else {
            estado.className = "disponible";
            estado.textContent = "Disponible";
          }
          celdaEstado.appendChild(estado);
          fila.appendChild(celdaEstado);

          const celdaAcciones = document.createElement("td");

          const botonEditar = document.createElement("a");
          botonEditar.href = "/editar-producto.html?id=" + producto.id;
          botonEditar.className = "btn btn-warning btn-sm me-2";
          botonEditar.textContent = "Editar";
          celdaAcciones.appendChild(botonEditar);

          const botonEliminar = document.createElement("button");
          botonEliminar.type = "button";
          botonEliminar.className = "btn btn-danger btn-sm";
          botonEliminar.textContent = "Eliminar";

          botonEliminar.addEventListener("click", function () {
            if (confirm("¿Seguro que querés eliminar este producto?")) {
              fetch("/api/productos/eliminar", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ id: producto.id }).toString()
              })
              .then(function (respuesta) {
                return respuesta.json().then(function (datos) {
                  if (!respuesta.ok) throw new Error(datos.error || "No se pudo eliminar.");
                  return datos;
                });
              })
              .then(function () { window.location.reload(); })
              .catch(function (error) { alert(error.message); });
            }
          });

          celdaAcciones.appendChild(botonEliminar);
          fila.appendChild(celdaAcciones);
          tabla.appendChild(fila);
        });
      })
      .catch(function (error) {
        console.error(error);
        tabla.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">No se pudieron cargar los productos.</td></tr>`;
      });
}

//Editar
const formEditar = document.getElementById("formulario-editar");

if (formEditar) {
    const CAMPOS = ["nombre", "modelo", "descripcion", "tipo_parte", "id_marca", "tipo_vehiculo", "tamano", "color", "cantidad", "precio"];
    const mensaje = document.getElementById("mensaje");
    const selectorMarca = document.getElementById("id_marca");

    const parametros = new URLSearchParams(window.location.search);
    const id = parametros.get("id");

    if (!id || !/^[0-9]+$/.test(id)) {
        mensaje.className = "alert alert-danger";
        mensaje.textContent = "El ID del producto no es válido.";
        formEditar.style.display = "none";
    } else {
        fetch("/api/marcas")
            .then(function (respuesta) {
                if (!respuesta.ok) throw new Error("No se pudieron cargar las marcas.");
                return respuesta.json();
            })
            .then(function (marcas) {
                selectorMarca.innerHTML = "";
                marcas.forEach(function (marca) {
                    const opcion = document.createElement("option");
                    opcion.value = marca.id;
                    opcion.textContent = marca.nombre;
                    selectorMarca.appendChild(opcion);
                });
                return fetch("/api/productos");
            })
            .then(function (respuesta) {
                if (!respuesta.ok) throw new Error("No se pudo consultar el producto.");
                return respuesta.json();
            })
            .then(function (productos) {
                const producto = productos.find(function (elemento) {
                    return String(elemento.id) === id;
                });

                if (!producto) throw new Error("No se encontró el producto.");

                document.getElementById("id").value = producto.id;
                document.getElementById("nombre").value = producto.nombre;
                document.getElementById("modelo").value = producto.modelo;
                document.getElementById("descripcion").value = producto.descripcion;
                document.getElementById("tipo_parte").value = producto.tipoParte;
                document.getElementById("id_marca").value = producto.idMarca;
                document.getElementById("tipo_vehiculo").value = producto.tipoVehiculo;
                document.getElementById("tamano").value = producto.tamano;
                document.getElementById("color").value = producto.color;
                document.getElementById("cantidad").value = producto.cantidad;
                document.getElementById("precio").value = producto.precio;
            })
            .catch(function (error) {
                mensaje.className = "alert alert-danger";
                mensaje.textContent = error.message;
                formEditar.style.display = "none";
            });
    }

    formEditar.addEventListener("submit", function (evento) {
        evento.preventDefault();
        const producto = {};
        ["id"].concat(CAMPOS).forEach(function (campo) {
            producto[campo] = document.getElementById(campo).value;
        });

        fetch("/api/productos/editar", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(producto).toString()
        })
        .then(function (respuesta) {
            return respuesta.json().then(function (datos) {
                if (!respuesta.ok) throw new Error(datos.error || "No se pudo editar.");
                return datos;
            });
        })
        .then(function (datos) {
            mensaje.className = "alert alert-success";
            mensaje.textContent = datos.mensaje;
            setTimeout(function () { window.location.href = "/admin-productos.html"; }, 1000);
        })
        .catch(function (error) {
            mensaje.className = "alert alert-danger";
            mensaje.textContent = error.message;
        });
    });
}


//Agregar
const formCrear = document.getElementById("formulario-producto");

if (formCrear) {
    const CAMPOS = ["nombre", "modelo", "descripcion", "tipo_parte", "id_marca", "tipo_vehiculo", "tamano", "color", "cantidad", "precio"];
    const mensaje = document.getElementById("mensaje");
    const selectorMarca = document.getElementById("id_marca");

    fetch("/api/marcas")
        .then(function (respuesta) {
            if (!respuesta.ok) throw new Error("No se pudieron cargar las marcas.");
            return respuesta.json();
        })
        .then(function (marcas) {
            selectorMarca.innerHTML = '<option value="">Seleccioná una marca</option>';
            marcas.forEach(function (marca) {
                const opcion = document.createElement("option");
                opcion.value = marca.id;
                opcion.textContent = marca.nombre;
                selectorMarca.appendChild(opcion);
            });
        })
        .catch(function (error) {
            mensaje.className = "alert alert-danger mt-3";
            mensaje.textContent = error.message;
        });

    formCrear.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const producto = {};
        CAMPOS.forEach(function (campo) {
            producto[campo] = document.getElementById(campo).value;
        });

        fetch("/api/productos/crear", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(producto).toString()
        })
        .then(function (respuesta) {
            return respuesta.json().then(function (datos) {
                if (!respuesta.ok) throw new Error(datos.error || "No se pudo guardar el producto.");
                return datos;
            });
        })
        .then(function (datos) {
            mensaje.className = "alert alert-success mt-3";
            mensaje.textContent = datos.mensaje;
            formCrear.reset();
        })
        .catch(function (error) {
            console.error(error);
            mensaje.className = "alert alert-danger mt-3";
            mensaje.textContent = error.message;
        });
    });
}
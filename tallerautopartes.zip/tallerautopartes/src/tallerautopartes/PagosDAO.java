package tallerautopartes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PagosDAO {

    public void insertar(Pagos pago) {
        String consulta_sql = "INSERT INTO Pagos (Metodo, Monto, Estado) VALUES (?,?,?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, pago.getMetodo());
            sentencia_sql.setDouble(2, pago.getMonto());
            sentencia_sql.setString(3, pago.getEstado());

            sentencia_sql.executeUpdate();
            System.out.println("Pago guardado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public ArrayList<Pagos> listar() {
        ArrayList<Pagos> lista_pagos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Pagos";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Pagos pago = new Pagos();
                pago.setIdPago(resultado.getInt("Id_Pago"));
                pago.setMetodo(resultado.getString("Metodo"));
                pago.setMonto(resultado.getDouble("Monto"));
                pago.setEstado(resultado.getString("Estado"));

                lista_pagos.add(pago);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_pagos;
    }

    public void actualizar(Pagos pago) {
        String consulta_sql = "UPDATE Pagos SET Metodo=?, Monto=?, Estado=? WHERE Id_Pago=?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, pago.getMetodo());
            sentencia_sql.setDouble(2, pago.getMonto());
            sentencia_sql.setString(3, pago.getEstado());
            sentencia_sql.setInt(4, pago.getIdPago());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public void eliminar(int id) {
        String consulta_sql = "DELETE FROM Pagos WHERE Id_Pago = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
}
package tallerautopartes;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

public class ServidorWeb {

    private static final String URL_BD = "jdbc:mysql://localhost:3306/Auto_partes";
    private static final String USUARIO_BD = "root";
    private static final String CONTRASENA_BD = "";

    public static void main(String[] args) throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0
        );

        servidor.createContext("/", new HttpHandler() {

           @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto HTML/CSS: " + ruta);
                Path archivo = null;
                if (ruta.equals("/")) {
                    archivo = Paths.get("src", "Web", "PaginaInicio.html");
                } else if (ruta.equals("/PaginaInicio.html")) {
                    archivo = Paths.get("src", "Web", "PaginaInicio.html");
                } else if (ruta.equals("/Usuario.html")) {
                    archivo = Paths.get("src", "Web", "Usuario.html");
                } else if (ruta.equals("/admin-categorias.html")) {
                    archivo = Paths.get("src", "Web", "admin-categorias.html");
                } else if (ruta.equals("/admin-configuracion.html")) {
                    archivo = Paths.get("src", "Web", "admin-configuracion.html");
                } else if (ruta.equals("/admin-informe.html")) {
                    archivo = Paths.get("src", "Web", "admin-informe.html");
                } else if (ruta.equals("/admin-marcas.html")) {
                    archivo = Paths.get("src", "Web", "admin-marcas.html");
                } else if (ruta.equals("/admin-pedidos.html")) {
                    archivo = Paths.get("src", "Web", "admin-pedidos.html");
                } else if (ruta.equals("/admin-productos.html")) {
                    archivo = Paths.get("src", "Web", "admin-productos.html");
                } else if (ruta.equals("/admin-resumen.html")) {
                    archivo = Paths.get("src", "Web", "admin-resumen.html");
                } else if (ruta.equals("/admin-usuario.html")) {
                    archivo = Paths.get("src", "Web", "admin-usuario.html");
                } else if (ruta.equals("/categorias.html")) {
                    archivo = Paths.get("src", "Web", "categorias.html");
                } else if (ruta.equals("/iniciar-sesion.html")) {
                    archivo = Paths.get("src", "Web", "iniciar-sesion.html");
                } else if (ruta.equals("/nosotros.html")) {
                    archivo = Paths.get("src", "Web", "nosotros.html");
                } else if (ruta.equals("/pagar.html")) {
                    archivo = Paths.get("src", "Web", "pagar.html");
                } else if (ruta.equals("/nuevo-producto.html")) {
                    archivo = Paths.get("src", "Web", "nuevo-producto.html");
                } else if (ruta.equals("/editar-producto.html")) {
                    archivo = Paths.get("src", "Web", "editar-producto.html");
                } else if (ruta.equals("/estilo_carrito-favorito.css")) {
                    archivo = Paths.get("src", "Web", "estilo_carrito-favorito.css");
                } else if (ruta.equals("/estilo_desarrollador.css")) {
                    archivo = Paths.get("src", "Web", "estilo_desarrollador.css");
                } else if (ruta.equals("/estilo_inicio.css")) {
                    archivo = Paths.get("src", "Web", "estilo_inicio.css");
                } else if (ruta.equals("/estilo_nosotros.css")) {
                    archivo = Paths.get("src", "Web", "estilo_nosotros.css");
                } else if (ruta.equals("/estilo_usuario.css")) {
                    archivo = Paths.get("src", "Web", "estilo_usuario.css");
                } else if (ruta.equals("/productos.css")) {
                    archivo = Paths.get("src", "Web", "productos.css");
                } else if (ruta.equals("/funciones.js")) {
                    archivo = Paths.get("src", "Web", "funciones.js");
                } else if (ruta.equals("/funciones-productos.js")) {
                    archivo = Paths.get("src", "Web", "funciones-productos.js");
                } else if (ruta.equals("/funciones-categorias.js")) {
                    archivo = Paths.get("src", "Web", "funciones-categorias.js");
                } else if (ruta.startsWith("/Imagenes/") && !ruta.contains("..")) {
                    archivo = Paths.get("src", "Web", ruta.substring(1));
                }
                System.out.println("Archivo: " + (archivo != null ? archivo.toAbsolutePath() : "No definido"));
 
                System.out.println("Existe: " + (archivo != null && Files.exists(archivo)));
 
                byte[] contenido;
                int codigo;
 
                if (archivo != null && Files.exists(archivo)) {
                    contenido = Files.readAllBytes(archivo);
                    codigo = 200;
                    if (ruta.endsWith(".css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );
 
                    } else if (ruta.endsWith(".js")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "application/javascript; charset=UTF-8"
                        );
 
                    } else if (ruta.endsWith(".png")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "image/png"
                        );
 
                    } else if (ruta.endsWith(".jpg")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "image/jpeg"
                        );
 
                    } else {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/html; charset=UTF-8"
                        );
                    }
                } else {
                    String mensaje = "Archivo no encontrado";
                    contenido = mensaje.getBytes(
                            StandardCharsets.UTF_8
                    );
                    codigo = 404;
                    intercambio.getResponseHeaders().set(
                            "Content-Type",
                            "text/plain; charset=UTF-8"
                    );
                }
                intercambio.sendResponseHeaders(
                        codigo, contenido.length
                );
                try (OutputStream salida =
                        intercambio.getResponseBody()) {
 
                    salida.write(contenido);
                }
            }
        });
 

        servidor.createContext("/api/productos", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto de productos: " + ruta);

                if (!ruta.equals("/api/productos")) {
                    enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
                    return;
                }

                String sql = "SELECT p.Id_Producto, p.Nombre, p.Descripcion, p.Tipo_Parte, "
                        + "p.Tamaño AS tamano, p.Cantidad, p.precio, p.color, p.Modelo, "
                        + "p.id_marca, m.nombre AS marca, p.Tipo_Vehiculo "
                        + "FROM Productos p "
                        + "LEFT JOIN Marcas m ON p.id_marca = m.id_marca "
                        + "ORDER BY p.Id_Producto";

                StringBuilder json = new StringBuilder();

                try (
                    Connection conexion = abrirConexion();
                    PreparedStatement sentencia = conexion.prepareStatement(sql);
                    ResultSet resultado = sentencia.executeQuery()
                ) {
                    json.append("[");
                    boolean primero = true;

                    while (resultado.next()) {
                        if (!primero) {
                            json.append(",");
                        }

                        int idMarca = resultado.getInt("id_marca");
                        boolean sinMarca = resultado.wasNull();

                        json.append("{");
                        json.append("\"id\":").append(resultado.getInt("Id_Producto")).append(",");
                        json.append("\"nombre\":\"").append(escaparJson(resultado.getString("Nombre"))).append("\",");
                        json.append("\"descripcion\":\"").append(escaparJson(resultado.getString("Descripcion"))).append("\",");
                        json.append("\"tipoParte\":\"").append(escaparJson(resultado.getString("Tipo_Parte"))).append("\",");
                        json.append("\"tamano\":\"").append(escaparJson(resultado.getString("tamano"))).append("\",");
                        json.append("\"cantidad\":").append(resultado.getInt("Cantidad")).append(",");
                        json.append("\"precio\":").append(resultado.getInt("precio")).append(",");
                        json.append("\"color\":\"").append(escaparJson(resultado.getString("color"))).append("\",");
                        json.append("\"modelo\":\"").append(escaparJson(resultado.getString("Modelo"))).append("\",");
                        json.append("\"idMarca\":").append(sinMarca ? "null" : String.valueOf(idMarca)).append(",");
                        json.append("\"marca\":\"").append(escaparJson(resultado.getString("marca"))).append("\",");
                        json.append("\"tipoVehiculo\":\"").append(escaparJson(resultado.getString("Tipo_Vehiculo"))).append("\"");
                        json.append("}");
                        primero = false;
                    }

                    json.append("]");
                    enviarRespuesta(intercambio, 200, json.toString());

                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
                }
            }
        });

        servidor.createContext("/api/marcas", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto de marcas: " + ruta);

                if (!ruta.equals("/api/marcas")) {
                    enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
                    return;
                }

                String sql = "SELECT id_marca, nombre FROM Marcas ORDER BY nombre";
                StringBuilder json = new StringBuilder();

                try (
                    Connection conexion = abrirConexion();
                    PreparedStatement sentencia = conexion.prepareStatement(sql);
                    ResultSet resultado = sentencia.executeQuery()
                ) {
                    json.append("[");
                    boolean primero = true;

                    while (resultado.next()) {
                        if (!primero) {
                            json.append(",");
                        }

                        json.append("{");
                        json.append("\"id\":").append(resultado.getInt("id_marca")).append(",");
                        json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\"");
                        json.append("}");
                        primero = false;
                    }

                    json.append("]");
                    enviarRespuesta(intercambio, 200, json.toString());

                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar las marcas\"}");
                }
            }
        });

        servidor.createContext("/api/productos/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                String error = validarProducto(datos);
                

                if (error != null) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"" + escaparJson(error) + "\"}");
                    return;
                }

                String sql = "INSERT INTO Productos "
                        + "(Nombre, Descripcion, Tipo_Parte, Tamaño, Cantidad, precio, "
                        + "color, Modelo, id_marca, Tipo_Vehiculo) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                try (
                    Connection conexion = abrirConexion();
                    PreparedStatement sentencia = conexion.prepareStatement(sql)
                ) {
                    sentencia.setString(1, datos.get("nombre").trim());
                    sentencia.setString(2, datos.get("descripcion").trim());
                    sentencia.setString(3, datos.get("tipo_parte").trim());
                    sentencia.setString(4, datos.get("tamano"));
                    sentencia.setInt(5, Integer.parseInt(datos.get("cantidad")));
                    sentencia.setInt(6, Integer.parseInt(datos.get("precio")));
                    sentencia.setString(7, datos.get("color").trim());
                    sentencia.setString(8, datos.get("modelo").trim());
                    sentencia.setInt(9, Integer.parseInt(datos.get("id_marca")));
                    sentencia.setString(10, datos.get("tipo_vehiculo"));

                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Producto guardado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar el producto\"}");
                    }

                } catch (SQLIntegrityConstraintViolationException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"La marca seleccionada no existe\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });

        servidor.createContext("/api/productos/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                int id;

                try {
                    id = Integer.parseInt(datos.get("id"));
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                    return;
                }

                String error = (id <= 0) ? "ID no valido" : validarProducto(datos);

                if (error != null) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"" + escaparJson(error) + "\"}");
                    return;
                }

                String sql = "UPDATE Productos SET Nombre = ?, Descripcion = ?, "
                        + "Tipo_Parte = ?, Tamaño = ?, Cantidad = ?, precio = ?, "
                        + "color = ?, Modelo = ?, id_marca = ?, Tipo_Vehiculo = ? "
                        + "WHERE Id_Producto = ?";

                try (
                    Connection conexion = abrirConexion();
                    PreparedStatement sentencia = conexion.prepareStatement(sql)
                ) {
                    sentencia.setString(1, datos.get("nombre").trim());
                    sentencia.setString(2, datos.get("descripcion").trim());
                    sentencia.setString(3, datos.get("tipo_parte").trim());
                    sentencia.setString(4, datos.get("tamano"));
                    sentencia.setInt(5, Integer.parseInt(datos.get("cantidad")));
                    sentencia.setInt(6, Integer.parseInt(datos.get("precio")));
                    sentencia.setString(7, datos.get("color").trim());
                    sentencia.setString(8, datos.get("modelo").trim());
                    sentencia.setInt(9, Integer.parseInt(datos.get("id_marca")));
                    sentencia.setString(10, datos.get("tipo_vehiculo"));
                    sentencia.setInt(11, id);

                    int filas = sentencia.executeUpdate();

                    if (filas > 0) {
                        enviarRespuesta(intercambio, 200,
                                "{\"mensaje\":\"Producto actualizado correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 404,
                                "{\"error\":\"No se encontro el producto\"}");
                    }

                } catch (SQLIntegrityConstraintViolationException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"La marca seleccionada no existe\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                }
            }
        });


        servidor.createContext("/api/productos/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));

                    if (id <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM Productos WHERE Id_Producto = ?";

                    try (
                        Connection conexion = abrirConexion();
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, id);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Producto eliminado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro el producto\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLIntegrityConstraintViolationException e) {
                    // La tabla Ventas referencia a Productos.
                    enviarRespuesta(intercambio, 409,
                            "{\"error\":\"No se puede eliminar: el producto tiene ventas asociadas\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                }
            }
        });

        //Iniciamos el servidor

        servidor.start();
        System.out.println("Servidor iniciado en http://localhost:8080");
    }

    private static Connection abrirConexion() throws SQLException {
        return DriverManager.getConnection(URL_BD, USUARIO_BD, CONTRASENA_BD);
    }

    // Revisa los datos de un producto. Devuelve el error o null si esta todo bien.
    private static String validarProducto(java.util.Map<String, String> datos) {

        String[] textos = {"nombre", "descripcion", "tipo_parte", "color", "modelo"};
        int[] maximos = {35, 50, 100, 25, 40};

        for (int i = 0; i < textos.length; i++) {
            String valor = datos.get(textos[i]);

            if (valor == null || valor.trim().isEmpty()) {
                return "Todos los campos son obligatorios";
            }

            if (valor.trim().length() > maximos[i]) {
                return "El campo " + textos[i] + " admite hasta " + maximos[i] + " caracteres";
            }
        }

        String tamaño = datos.get("tamaño");

        if (tamaño == null || !(tamaño.equals("Chico")
                || tamaño.equals("Mediano") || tamaño.equals("Grande"))) {
            return "El tamano debe ser Chico, Mediano o Grande";
        }

        String tipoVehiculo = datos.get("tipo_vehiculo");

        if (tipoVehiculo == null || !(tipoVehiculo.equals("moto")
                || tipoVehiculo.equals("auto") || tipoVehiculo.equals("camion"))) {
            return "El tipo de vehiculo debe ser moto, auto o camion";
        }

        try {
            int cantidad = Integer.parseInt(datos.get("cantidad"));
            int precio = Integer.parseInt(datos.get("precio"));
            int idMarca = Integer.parseInt(datos.get("id_marca"));

            if (cantidad < 0 || precio < 0 || idMarca <= 0) {
                return "Cantidad y precio no pueden ser negativos y la marca es obligatoria";
            }
        } catch (NumberFormatException e) {
            return "Cantidad, precio y marca deben ser numeros enteros";
        }

        return null;
    }
    private static String validarUsuario(java.util.Map<String, String> datos) {

        String[] textos = {"nombre", "apellido", "usuario", "contraseña", "dni","telefono", "direccion"};
        int[] maximos = {35, 35, 45, 45, 8, 15, 45, };

        for (int i = 0; i < textos.length; i++) {
            String valor = datos.get(textos[i]);

            if (valor == null || valor.trim().isEmpty()) {
                return "Todos los campos son obligatorios";
            }

            if (valor.trim().length() > maximos[i]) {
                return "El campo " + textos[i] + " admite hasta " + maximos[i] + " caracteres";
            }
        }

        String tamaño = datos.get("tamaño");

        if (tamaño == null || !(tamaño.equals("Chico")
                || tamaño.equals("Mediano") || tamaño.equals("Grande"))) {
            return "El tamano debe ser Chico, Mediano o Grande";
        }

        String tipoVehiculo = datos.get("tipo_vehiculo");

        if (tipoVehiculo == null || !(tipoVehiculo.equals("moto")
                || tipoVehiculo.equals("auto") || tipoVehiculo.equals("camion"))) {
            return "El tipo de vehiculo debe ser moto, auto o camion";
        }

        try {
            int cantidad = Integer.parseInt(datos.get("cantidad"));
            int precio = Integer.parseInt(datos.get("precio"));
            int idMarca = Integer.parseInt(datos.get("id_marca"));

            if (cantidad < 0 || precio < 0 || idMarca <= 0) {
                return "Cantidad y precio no pueden ser negativos y la marca es obligatoria";
            }
        } catch (NumberFormatException e) {
            return "Cantidad, precio y marca deben ser numeros enteros";
        }

        return null;
    }

    private static String tipoContenido(String nombreArchivo) {
        String nombre = nombreArchivo.toLowerCase();

        if (nombre.endsWith(".html")) {
            return "text/html; charset=UTF-8";
        } else if (nombre.endsWith(".css")) {
            return "text/css; charset=UTF-8";
        } else if (nombre.endsWith(".js")) {
            return "application/javascript; charset=UTF-8";
        } else if (nombre.endsWith(".png")) {
            return "image/png";
        } else if (nombre.endsWith(".jpg") || nombre.endsWith(".jpeg")) {
            return "image/jpeg";
        } else if (nombre.endsWith(".svg")) {
            return "image/svg+xml";
        } else if (nombre.endsWith(".ico")) {
            return "image/x-icon";
        }

        return "application/octet-stream";
    }

    private static java.util.Map<String, String> leerParametros(
            HttpExchange intercambio) throws IOException {

        java.io.InputStream entrada = intercambio.getRequestBody();

        java.io.ByteArrayOutputStream buffer =
                new java.io.ByteArrayOutputStream();

        int dato;

        while ((dato = entrada.read()) != -1) {
            buffer.write(dato);
        }

        String cuerpo = new String(
                buffer.toByteArray(),
                StandardCharsets.UTF_8
        );

        java.util.Map<String, String> parametros =
                new java.util.HashMap<String, String>();

        String[] partes = cuerpo.split("&");

        for (String parte : partes) {
            String[] campo = parte.split("=", 2);

            String clave = java.net.URLDecoder.decode(
                    campo[0], "UTF-8"
            );

            String valor = "";

            if (campo.length > 1) {
                valor = java.net.URLDecoder.decode(
                        campo[1], "UTF-8"
                );
            }

            parametros.put(clave, valor);
        }

        return parametros;
    }

    private static String escaparJson(String texto) {

        if (texto == null) {
            return "";
        }

        return texto
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static void enviarRespuesta(
            HttpExchange intercambio,
            int codigo,
            String respuesta
    ) throws IOException {

        byte[] contenido = respuesta.getBytes(
                StandardCharsets.UTF_8
        );

        intercambio.getResponseHeaders().set(
                "Content-Type",
                "application/json; charset=UTF-8"
        );

        intercambio.sendResponseHeaders(
                codigo, contenido.length
        );

        try (OutputStream salida =
                intercambio.getResponseBody()) {

            salida.write(contenido);
        }
    }
}

package tallerautopartes;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServidorWeb {
    public static void main(String[] args) throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0
        );

        servidor.createContext("/", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto HTML/CSS: " + ruta);
                Path archivo = null;
                if (ruta.equals("/")) {
                    archivo = Paths.get("src", "Web", "PaginaInicio.html");
                } else if (ruta.equals("/Usuario.html")) {
                    archivo = Paths.get("src", "Web", "Usuario.html");
                } else if (ruta.equals("/estilo_inicio.css")) {
                    archivo = Paths.get("src", "Web", "estilo_inicio.css");
                }else if(ruta.equals("/admin-categorias.html")){
                    archivo = Paths.get("src", "Web", "admin-categorias.html");
                } else if (ruta.equals("/admin-configuracion.html")) {
                    archivo = Paths.get("src", "Web", "admin-configuracion.html");
                } else if (ruta.equals("/admin-informe.html")) {
                    archivo = Paths.get("src", "Web", "admin-informe.html");
                } else if (ruta.equals("/admin-marcas.html")) {
                    archivo = Paths.get("src", "Web", "admin-marcas.html");
                } else if (ruta.equals("/admin-pedidos.html")) {
                    archivo = Paths.get("src", "Web", "admin-pedidos.html");
                } else if (ruta.equals("/admin-productos.html")) {
                    archivo = Paths.get("src", "Web", "admin-configuracion.html");
                } else if (ruta.equals("/admin-resumen.html")) {
                    archivo = Paths.get("src", "Web", "admin-resumen.html");
                } else if (ruta.equals("/admin-usuario.html")) {
                    archivo = Paths.get("src", "Web", "admin-usuario.html");
                } else if (ruta.equals("/carrito.html")) {
                    archivo = Paths.get("src", "Web", "carrito.html");
                } else if (ruta.equals("/categorias.html")) {
                    archivo = Paths.get("src", "Web", "categorias.html");
                } else if (ruta.equals("/favoritos.html")) {
                    archivo = Paths.get("src", "Web", "favoritos.html");
                }
                System.out.println("Archivo: " + (archivo != null ? archivo.toAbsolutePath() : "No definido"));

                System.out.println("Existe: " + (archivo != null && Files.exists(archivo)));

                byte[] contenido;
                int codigo;

                if (archivo != null && Files.exists(archivo)) {
                    contenido = Files.readAllBytes(archivo);
                    codigo = 200;
                    if (ruta.equals("/estilos.css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );

                    }else{
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/html; charset=UTF-8"
                        );
                    }
                } else {
                    String mensaje = "Archivo no encontrado";
                    contenido = mensaje.getBytes(
                            StandardCharsets.UTF_8
                    );
                    codigo = 404;
                    intercambio.getResponseHeaders().set(
                            "Content-Type",
                            "text/plain; charset=UTF-8"
                    );
                }
                intercambio.sendResponseHeaders(
                        codigo, contenido.length
                );
                try (OutputStream salida =
                        intercambio.getResponseBody()) {

                    salida.write(contenido);
                }
            }
        });
        servidor.createContext("/api/personas", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto de personas: " + ruta);
                if (!ruta.equals("/api/personas")) {
                    enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
                    return;
                }
                String sql = "SELECT id, dni, nombre, apellido, edad, correo FROM persona";
                StringBuilder json = new StringBuilder();
                try (
                    Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/personas","root","");
                    PreparedStatement sentencia = conexion.prepareStatement(sql);
                    ResultSet resultado = sentencia.executeQuery()
                ) {
                    json.append("[");
                    boolean primero = true;
                    while (resultado.next()) {
                        if (!primero) {
                            json.append(",");
                        }
                        json.append("{");
                        json.append("\"id\":").append(resultado.getInt("id")).append(",");
                        json.append("\"dni\":").append(resultado.getInt("dni")).append(",");
                        json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\",");
                        json.append("\"apellido\":\"").append(escaparJson(resultado.getString("apellido"))).append("\",");
                        json.append("\"edad\":").append(resultado.getInt("edad")).append(",");
                        json.append("\"correo\":\"").append(escaparJson(resultado.getString("correo"))).append("\"");
                        json.append("}");
                        primero = false;
                    }
                    json.append("]");
                    enviarRespuesta(intercambio, 200, json.toString());
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
                }
            }
        });
        
        
        servidor.createContext("/api/personas/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                // Obtener los valores del formulario.
                String dniTexto = datos.get("dni");
                String nombre = datos.get("nombre");
                String apellido = datos.get("apellido");
                String edadTexto = datos.get("edad");
                String correo = datos.get("correo");

                // Validar los campos.
                if (dniTexto == null || nombre == null
                        || apellido == null || edadTexto == null
                        || correo == null || dniTexto.trim().isEmpty()
                        || nombre.trim().isEmpty()
                        || apellido.trim().isEmpty()
                        || edadTexto.trim().isEmpty()
                        || correo.trim().isEmpty()) {

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                int dni;
                int edad;

                try {
                    dni = Integer.parseInt(dniTexto);
                    edad = Integer.parseInt(edadTexto);
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"DNI y edad deben ser numeros enteros\"}");
                    return;
                }

                // Preparar la consulta SQL.
                String sql = "INSERT INTO persona "
                        + "(dni, nombre, apellido, edad, correo) "
                        + "VALUES (?, ?, ?, ?, ?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/personas",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                    sentencia.setInt(1, dni);
                    sentencia.setString(2, nombre.trim());
                    sentencia.setString(3, apellido.trim());
                    sentencia.setInt(4, edad);
                    sentencia.setString(5, correo.trim());

                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Persona guardada correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar la persona\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });


        
        //Iniciamos el servidor
        
        servidor.start();
        System.out.println("Servidor iniciado en http://localhost:8080");
    }
    
    private static String escaparJson(String texto) {

        if (texto == null) {
            return "";
        }

        return texto
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static void enviarRespuesta(
            HttpExchange intercambio,
            int codigo,
            String respuesta
    ) throws IOException {

        byte[] contenido = respuesta.getBytes(
                StandardCharsets.UTF_8
        );

        intercambio.getResponseHeaders().set(
                "Content-Type",
                "application/json; charset=UTF-8"
        );

        intercambio.sendResponseHeaders(
                codigo, contenido.length
        );

        try (OutputStream salida =
                intercambio.getResponseBody()) {

            salida.write(contenido);
        }
    }
}

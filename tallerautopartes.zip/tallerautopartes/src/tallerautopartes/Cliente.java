package tallerautopartes;

import javax.swing.JOptionPane;

public class Cliente extends Persona {
    private int idCliente;
    private String direccion;

    public Cliente() {
    }

    public Cliente(String nombre, String apellido, int dni, String telefono, String direccion) {
        super(nombre, apellido, telefono, dni);
        this.direccion = direccion;
    }

    @Override
    public void mostrarPersona() {
        JOptionPane.showMessageDialog(null,
            "Nombre: " + nombre + "\n" +
            "Apellido: " + apellido + "\n" +
            "Telefono: " + telefono + "\n" +
            "Dni: " + dni + "\n" +
            "Direccion: " + direccion);
    }

    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
}
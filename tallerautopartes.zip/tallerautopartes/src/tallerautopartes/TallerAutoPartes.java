
package tallerautopartes;

import javax.swing.JOptionPane;


public class TallerAutoPartes {

    
    public static void main(String[] args) {
        
        GestionPersona empresa = new GestionPersona();
        VentanaPrincipal ventana1 = new VentanaPrincipal(empresa);
        ventana1.setVisible(true);
        
        ventana1.setLocationRelativeTo(null);
        
        
        
        
        
       
    
    }
    
}

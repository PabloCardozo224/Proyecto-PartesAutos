package tallerautopartes;

import javax.swing.JOptionPane;

public class TallerAutoPartes {

    public static void main(String[] args) {

        Empresa empresa = new Empresa();
        VentanaInicioSesion ventana1 = new VentanaInicioSesion(empresa);
        ventana1.setVisible(true);

        ventana1.setLocationRelativeTo(null);

    }

}
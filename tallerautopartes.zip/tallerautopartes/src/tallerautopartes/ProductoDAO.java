package tallerautopartes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductoDAO {

    public void insertar(Producto producto) {
        String consulta_sql = "INSERT INTO productos (nombre, descripcion, tipo_parte, tamaño, cantidad, precio, color, modelo, Tipo_Vehiculo) VALUES (?,?,?,?,?,?,?,?,?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, producto.getNombre());
            sentencia_sql.setString(2, producto.getDescripcion());
            sentencia_sql.setString(3, producto.getTipoParte());
            sentencia_sql.setString(4, producto.getTamaño());
            sentencia_sql.setInt(5, producto.getCantidad());
            sentencia_sql.setDouble(6, producto.getPrecio());
            sentencia_sql.setString(7, producto.getColor());
            sentencia_sql.setString(8, producto.getModelo());
            sentencia_sql.setString(9, producto.getTipoVehiculo());

            sentencia_sql.executeUpdate();
            System.out.println("Producto guardado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public ArrayList<Producto> listar() {
        ArrayList<Producto> lista_productos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM productos";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Producto producto = new Producto();
                producto.setIdProducto(resultado.getInt("Id_Producto"));
                producto.setNombre(resultado.getString("Nombre"));
                producto.setDescripcion(resultado.getString("Descripcion"));
                producto.setTipoParte(resultado.getString("Tipo_Parte"));
                producto.setTamaño(resultado.getString("Tamaño"));
                producto.setCantidad(resultado.getInt("Cantidad"));
                producto.setPrecio(resultado.getDouble("precio"));
                producto.setColor(resultado.getString("color"));
                producto.setModelo(resultado.getString("Modelo"));
                producto.setTipoVehiculo(resultado.getString("Tipo_Vehiculo"));

                lista_productos.add(producto);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_productos;
    }

    public void actualizar(Producto producto) {
        String consulta_sql = "UPDATE productos SET Nombre=?, Descripcion=?, Tipo_Parte=?, Tamaño=?, Cantidad=?, precio=?, color=?, Modelo=?, Tipo_Vehiculo=? WHERE Id_Producto=?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, producto.getNombre());
            sentencia_sql.setString(2, producto.getDescripcion());
            sentencia_sql.setString(3, producto.getTipoParte());
            sentencia_sql.setString(4, producto.getTamaño());
            sentencia_sql.setInt(5, producto.getCantidad());
            sentencia_sql.setDouble(6, producto.getPrecio());
            sentencia_sql.setString(7, producto.getColor());
            sentencia_sql.setString(8, producto.getModelo());
            sentencia_sql.setString(9, producto.getTipoVehiculo());
            sentencia_sql.setInt(10, producto.getIdProducto());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public void eliminar(int id) {
        String consulta_sql = "DELETE FROM productos WHERE Id_Producto = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    public ArrayList<Producto> buscar(String Tipo_Vehiculo) {
        ArrayList<Producto> lista_productos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM productos WHERE Tipo_Vehiculo = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, Tipo_Vehiculo);
            ResultSet resultado = sentencia_sql.executeQuery();

            
             while (resultado.next()) {
                Producto producto = new Producto();
                producto.setIdProducto(resultado.getInt("Id_Producto"));
                producto.setNombre(resultado.getString("Nombre"));
                producto.setDescripcion(resultado.getString("Descripcion"));
                producto.setTipoParte(resultado.getString("Tipo_Parte"));
                producto.setTamaño(resultado.getString("Tamaño"));
                producto.setCantidad(resultado.getInt("Cantidad"));
                producto.setPrecio(resultado.getDouble("precio"));
                producto.setColor(resultado.getString("color"));
                producto.setModelo(resultado.getString("Modelo"));
                producto.setTipoVehiculo(resultado.getString("Tipo_Vehiculo"));

                lista_productos.add(producto);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
         return lista_productos;
    }
}
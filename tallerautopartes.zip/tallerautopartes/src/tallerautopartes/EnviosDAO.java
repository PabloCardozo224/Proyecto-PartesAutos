package tallerautopartes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EnviosDAO {

    public void insertar(Envios envio) {
        String consulta_sql = "INSERT INTO Envios (N_casa, nombre_calle, nombre_barrio, nombre_provincia, nombre_localidad) VALUES (?,?,?,?,?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, envio.getNCasa());
            sentencia_sql.setString(2, envio.getNombreCalle());
            sentencia_sql.setString(3, envio.getNombreBarrio());
            sentencia_sql.setString(4, envio.getNombreProvincia());
            sentencia_sql.setString(5, envio.getNombreLocalidad());

            sentencia_sql.executeUpdate();
            System.out.println("Envio guardado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public ArrayList<Envios> listar() {
        ArrayList<Envios> lista_envios = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Envios";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Envios envio = new Envios();
                envio.setIdEnvio(resultado.getInt("ID_Envio"));
                envio.setNCasa(resultado.getInt("N_casa"));
                envio.setNombreCalle(resultado.getString("nombre_calle"));
                envio.setNombreBarrio(resultado.getString("nombre_barrio"));
                envio.setNombreProvincia(resultado.getString("nombre_provincia"));
                envio.setNombreLocalidad(resultado.getString("nombre_localidad"));

                lista_envios.add(envio);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_envios;
    }

    public void actualizar(Envios envio) {
        String consulta_sql = "UPDATE Envios SET N_casa=?, nombre_calle=?, nombre_barrio=?, nombre_provincia=?, nombre_localidad=? WHERE ID_Envio=?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, envio.getNCasa());
            sentencia_sql.setString(2, envio.getNombreCalle());
            sentencia_sql.setString(3, envio.getNombreBarrio());
            sentencia_sql.setString(4, envio.getNombreProvincia());
            sentencia_sql.setString(5, envio.getNombreLocalidad());
            sentencia_sql.setInt(6, envio.getIdEnvio());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public void eliminar(int id) {
        String consulta_sql = "DELETE FROM Envios WHERE ID_Envio = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    public ArrayList<Envios> buscar(String nombre_provincia) {
    ArrayList<Envios> lista_envios = new ArrayList<>();
    String consulta_sql = "SELECT * FROM Envios WHERE nombre_provincia = ?";
    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        sentencia_sql.setString(1, nombre_provincia);
        ResultSet resultado = sentencia_sql.executeQuery();

        while (resultado.next()) {
            Envios envio = new Envios();
            envio.setIdEnvio(resultado.getInt("ID_Envio"));
            envio.setNCasa(resultado.getInt("N_casa"));
            envio.setNombreCalle(resultado.getString("nombre_calle"));
            envio.setNombreBarrio(resultado.getString("nombre_barrio"));
            envio.setNombreProvincia(resultado.getString("nombre_provincia"));
            envio.setNombreLocalidad(resultado.getString("nombre_localidad"));

            lista_envios.add(envio);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return lista_envios;
}
}
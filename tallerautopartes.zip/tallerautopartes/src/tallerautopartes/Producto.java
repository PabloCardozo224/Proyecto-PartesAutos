package tallerautopartes;

public class Producto {

    private int idProducto;
    private String nombre;
    private String descripcion;
    private String tipoParte;
    private String tamaño;
    private int cantidad;
    private double precio;
    private String color;
    private String modelo;
    private String tipoVehiculo;

    public Producto() {
    }

    public Producto(String nombre, String descripcion, String tipoParte, String tamaño,
                    int cantidad, double precio, String color, String modelo, String tipoVehiculo) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipoParte = tipoParte;
        this.tamaño = tamaño;
        this.cantidad = cantidad;
        this.precio = precio;
        this.color = color;
        this.modelo = modelo;
        this.tipoVehiculo = tipoVehiculo;
    }

    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getTipoParte() { return tipoParte; }
    public void setTipoParte(String tipoParte) { this.tipoParte = tipoParte; }

    public String getTamaño() { return tamaño; }
    public void setTamaño(String tamaño) { this.tamaño = tamaño; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public String getTipoVehiculo() { return tipoVehiculo; }
    public void setTipoVehiculo(String tipoVehiculo) { this.tipoVehiculo = tipoVehiculo; }
}
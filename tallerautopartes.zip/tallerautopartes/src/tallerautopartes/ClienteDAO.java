package tallerautopartes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO {

    public void insertar(Cliente cliente) {
        String consulta_sql = "INSERT INTO clientes (dni, nombre, apellido, telefono, direccion) VALUES (?,?,?,?,?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, cliente.getDni());
            sentencia_sql.setString(2, cliente.getNombre());
            sentencia_sql.setString(3, cliente.getApellido());
            sentencia_sql.setString(4, cliente.getTelefono());
            sentencia_sql.setString(5, cliente.getDireccion());

            sentencia_sql.executeUpdate();
            System.out.println("Cliente guardado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public ArrayList<Cliente> listar() {
        ArrayList<Cliente> lista_clientes = new ArrayList<>();
        String consulta_sql = "SELECT * FROM clientes";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Cliente cliente = new Cliente();
                cliente.setIdCliente(resultado.getInt("Id_cliente"));
                cliente.setDni(resultado.getInt("DNI"));
                cliente.setNombre(resultado.getString("Nombre"));
                cliente.setApellido(resultado.getString("Apellido"));
                cliente.setTelefono(resultado.getString("Telefono"));
                cliente.setDireccion(resultado.getString("Direccion"));

                lista_clientes.add(cliente);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_clientes;
    }

    public void actualizar(Cliente cliente) {
        String consulta_sql = "UPDATE clientes SET DNI=?, Nombre=?, Apellido=?, Telefono=?, Direccion=? WHERE Id_cliente=?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, cliente.getDni());
            sentencia_sql.setString(2, cliente.getNombre());
            sentencia_sql.setString(3, cliente.getApellido());
            sentencia_sql.setString(4, cliente.getTelefono());
            sentencia_sql.setString(5, cliente.getDireccion());
            sentencia_sql.setInt(6, cliente.getIdCliente());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public void eliminar(int id) {
        String consulta_sql = "DELETE FROM clientes WHERE Id_cliente = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    public ArrayList<Cliente> buscar(String Nombre) {
    ArrayList<Cliente> lista_clientes = new ArrayList<>();
    String consulta_sql = "SELECT * FROM clientes WHERE Nombre = ?";
    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        sentencia_sql.setString(1, Nombre);
        ResultSet resultado = sentencia_sql.executeQuery();

        while (resultado.next()) {
            Cliente cliente = new Cliente();
            cliente.setIdCliente(resultado.getInt("Id_cliente"));
            cliente.setDni(resultado.getInt("DNI"));
            cliente.setNombre(resultado.getString("Nombre"));
            cliente.setApellido(resultado.getString("Apellido"));
            cliente.setTelefono(resultado.getString("Telefono"));
            cliente.setDireccion(resultado.getString("Direccion"));

            lista_clientes.add(cliente);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return lista_clientes;
}
    
}
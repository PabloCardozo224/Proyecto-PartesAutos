package tallerautopartes;

public class Envios {

    private int idEnvio;
    private int nCasa;
    private String nombreCalle;
    private String nombreBarrio;
    private String nombreProvincia;
    private String nombreLocalidad;

    public Envios() {
    }

    public Envios(int nCasa, String nombreCalle, String nombreBarrio,
                  String nombreProvincia, String nombreLocalidad) {
        this.nCasa = nCasa;
        this.nombreCalle = nombreCalle;
        this.nombreBarrio = nombreBarrio;
        this.nombreProvincia = nombreProvincia;
        this.nombreLocalidad = nombreLocalidad;
    }

    public int getIdEnvio() {
        return idEnvio;
    }

    public void setIdEnvio(int idEnvio) {
        this.idEnvio = idEnvio;
    }

    public int getNCasa() {
        return nCasa;
    }

    public void setNCasa(int nCasa) {
        this.nCasa = nCasa;
    }

    public String getNombreCalle() {
        return nombreCalle;
    }

    public void setNombreCalle(String nombreCalle) {
        this.nombreCalle = nombreCalle;
    }

    public String getNombreBarrio() {
        return nombreBarrio;
    }

    public void setNombreBarrio(String nombreBarrio) {
        this.nombreBarrio = nombreBarrio;
    }

    public String getNombreProvincia() {
        return nombreProvincia;
    }

    public void setNombreProvincia(String nombreProvincia) {
        this.nombreProvincia = nombreProvincia;
    }

    public String getNombreLocalidad() {
        return nombreLocalidad;
    }

    public void setNombreLocalidad(String nombreLocalidad) {
        this.nombreLocalidad = nombreLocalidad;
    }
}
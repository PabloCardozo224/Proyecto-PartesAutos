package tallerautopartes;

public class Ventas {

    private int idVentas;
    private String fechaVenta;
    private int cantidadProductos;
    private String tipoPedido;

    public Ventas() {
    }

    public Ventas(String fechaVenta, int cantidadProductos, String tipoPedido) {
        this.fechaVenta = fechaVenta;
        this.cantidadProductos = cantidadProductos;
        this.tipoPedido = tipoPedido;
    }

    public int getIdVentas() {
        return idVentas;
    }

    public void setIdVentas(int idVentas) {
        this.idVentas = idVentas;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getCantidadProductos() {
        return cantidadProductos;
    }

    public void setCantidadProductos(int cantidadProductos) {
        this.cantidadProductos = cantidadProductos;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }
}
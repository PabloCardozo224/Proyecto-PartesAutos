package tallerautopartes;

import javax.swing.JOptionPane;

public class Empleado extends Persona {
    private int idEmpleado;
    private String puesto;
    private String rol;

    public Empleado() {
    }

    public Empleado(String nombre, String apellido, int dni, String telefono, String puesto, String rol) {
        super(nombre, apellido, telefono, dni);
        this.puesto = puesto;
        this.rol = rol;
    }

    @Override
    public void mostrarPersona() {
        JOptionPane.showMessageDialog(null,
            "Nombre: " + nombre + "\n" +
            "Apellido: " + apellido + "\n" +
            "Telefono: " + telefono + "\n" +
            "Dni: " + dni + "\n" +
            "Puesto: " + puesto + "\n" +
            "Rol: " + rol);
    }

    public int getIdEmpleado() { return idEmpleado; }
    public void setIdEmpleado(int idEmpleado) { this.idEmpleado = idEmpleado; }

    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
}
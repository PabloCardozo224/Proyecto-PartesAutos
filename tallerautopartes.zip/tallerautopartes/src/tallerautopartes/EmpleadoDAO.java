package tallerautopartes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmpleadoDAO {

    public void insertar(Empleado empleado) {
        String consulta_sql = "INSERT INTO empleados (Nombre, Apellido, DNI, Telefono, Puesto, Rol) VALUES (?,?,?,?,?,?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, empleado.getNombre());
            sentencia_sql.setString(2, empleado.getApellido());
            sentencia_sql.setInt(3, empleado.getDni());
            sentencia_sql.setString(4, empleado.getTelefono());
            sentencia_sql.setString(5, empleado.getPuesto());
            sentencia_sql.setString(6, empleado.getRol());

            sentencia_sql.executeUpdate();
            System.out.println("Empleado guardado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public ArrayList<Empleado> listar() {
        ArrayList<Empleado> lista_empleados = new ArrayList<>();
        String consulta_sql = "SELECT * FROM empleados";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Empleado empleado = new Empleado();
                empleado.setIdEmpleado(resultado.getInt("Id_Empleado"));
                empleado.setNombre(resultado.getString("Nombre"));
                empleado.setApellido(resultado.getString("Apellido"));
                empleado.setDni(resultado.getInt("DNI"));
                empleado.setTelefono(resultado.getString("Telefono"));
                empleado.setPuesto(resultado.getString("Puesto"));
                empleado.setRol(resultado.getString("Rol"));

                lista_empleados.add(empleado);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_empleados;
    }

    public void actualizar(Empleado empleado) {
        String consulta_sql = "UPDATE empleados SET Nombre=?, Apellido=?, DNI=?, Telefono=?, Puesto=?, Rol=? WHERE Id_Empleado=?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, empleado.getNombre());
            sentencia_sql.setString(2, empleado.getApellido());
            sentencia_sql.setInt(3, empleado.getDni());
            sentencia_sql.setString(4, empleado.getTelefono());
            sentencia_sql.setString(5, empleado.getPuesto());
            sentencia_sql.setString(6, empleado.getRol());
            sentencia_sql.setInt(7, empleado.getIdEmpleado());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public void eliminar(int id) {
        String consulta_sql = "DELETE FROM empleados WHERE Id_Empleado = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    public ArrayList<Empleado> buscar(String Puesto) {
    ArrayList<Empleado> lista_empleados = new ArrayList<>();
    String consulta_sql = "SELECT * FROM empleados WHERE Puesto = ?";
    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        sentencia_sql.setString(1, Puesto);
        ResultSet resultado = sentencia_sql.executeQuery();

        while (resultado.next()) {
            Empleado empleado = new Empleado();
            empleado.setIdEmpleado(resultado.getInt("Id_Empleado"));
            empleado.setNombre(resultado.getString("Nombre"));
            empleado.setApellido(resultado.getString("Apellido"));
            empleado.setDni(resultado.getInt("DNI"));
            empleado.setTelefono(resultado.getString("Telefono"));
            empleado.setPuesto(resultado.getString("Puesto"));
            empleado.setRol(resultado.getString("Rol"));

            lista_empleados.add(empleado);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return lista_empleados;
}
}
package tallerautopartes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class VentasDAO {

    public void insertar(Ventas venta) {
        String consulta_sql = "INSERT INTO Ventas (Fecha_venta, cantidad_productos, Tipo_pedido, Id_Producto, id_Empleado, ID_Envio, Id_Pago) VALUES (?,?,?,1,1,1,1)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, venta.getFechaVenta());
            sentencia_sql.setInt(2, venta.getCantidadProductos());
            sentencia_sql.setString(3, venta.getTipoPedido());

            sentencia_sql.executeUpdate();
            System.out.println("Venta guardada exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public ArrayList<Ventas> listar() {
        ArrayList<Ventas> lista_ventas = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Ventas";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Ventas venta = new Ventas();
                venta.setIdVentas(resultado.getInt("id_Ventas"));
                venta.setFechaVenta(resultado.getString("Fecha_venta"));
                venta.setCantidadProductos(resultado.getInt("cantidad_productos"));
                venta.setTipoPedido(resultado.getString("Tipo_pedido"));

                lista_ventas.add(venta);
            }
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
        return lista_ventas;
    }

    public void actualizar(Ventas venta) {
        String consulta_sql = "UPDATE Ventas SET Fecha_venta=?, cantidad_productos=?, Tipo_pedido=? WHERE id_Ventas=?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, venta.getFechaVenta());
            sentencia_sql.setInt(2, venta.getCantidadProductos());
            sentencia_sql.setString(3, venta.getTipoPedido());
            sentencia_sql.setInt(4, venta.getIdVentas());

            sentencia_sql.executeUpdate();
            System.out.println("Datos actualizados exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }

    public void eliminar(int id) {
        String consulta_sql = "DELETE FROM Ventas WHERE id_Ventas = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado exitosamente!");
        } catch (SQLException ex) {
            System.out.println("ERROR " + ex.getMessage());
        }
    }
    
    public ArrayList<Ventas> buscar(String Tipo_pedido) {
    ArrayList<Ventas> lista_ventas = new ArrayList<>();
    String consulta_sql = "SELECT * FROM Ventas WHERE Tipo_pedido = ?";
    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        sentencia_sql.setString(1, Tipo_pedido);
        ResultSet resultado = sentencia_sql.executeQuery();

        while (resultado.next()) {
            Ventas venta = new Ventas();
            venta.setIdVentas(resultado.getInt("id_Ventas"));
            venta.setFechaVenta(resultado.getString("Fecha_venta"));
            venta.setCantidadProductos(resultado.getInt("cantidad_productos"));
            venta.setTipoPedido(resultado.getString("Tipo_pedido"));

            lista_ventas.add(venta);
        }
    } catch (SQLException ex) {
        System.out.println("ERROR " + ex.getMessage());
    }
    return lista_ventas;
}
}
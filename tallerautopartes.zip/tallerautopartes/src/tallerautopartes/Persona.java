package tallerautopartes;

public abstract class Persona {
    protected String nombre;
    protected String apellido;
    protected int dni;
    protected String telefono;

    public Persona() {
    }

    public Persona(String nombre, String apellido, String telefono, int dni) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.dni = dni;
    }

    public abstract void mostrarPersona();

    public String getNombre() { 
        return nombre; 
    }
    public void setNombre(String nombre) {
        this.nombre = nombre; 
    }

    public String getApellido() { 
        return apellido; 
    }
    public void setApellido(String apellido) { 
        this.apellido = apellido; 
    }

    public int getDni() { 
        return dni; 
    }
    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getTelefono() {
        return telefono; 
    }
    public void setTelefono(String telefono) { 
        this.telefono = telefono;
    }
}
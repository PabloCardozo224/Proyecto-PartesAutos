package tallerautopartes;

public class Pagos {

    private int idPago;
    private String metodo;
    private double monto;
    private String estado;

    public Pagos() {
    }

    public Pagos(String metodo, double monto, String estado) {
        this.metodo = metodo;
        this.monto = monto;
        this.estado = estado;
    }

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
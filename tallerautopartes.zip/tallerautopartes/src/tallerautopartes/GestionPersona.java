/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallerautopartes;

/**
 *
 * @author Redes-20
 */
public class GestionPersona {
    
}
